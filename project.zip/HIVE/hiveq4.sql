create table stock_table2 as select
state, sub_industry, stock_start.company_name, ((stock_end.close- stock_start.open)/stock_start.open)*100 growth_percent
from (select  st1.company_name,open from stock_data sd, stock_table1 st1 where sd.trading_year=st1.min_year and
sd.trading_month=st1.min_month and sd.company_name=st1.company_name)stock_start,
(select st1.company_name, close from stock_data sd, stock_table1 st1 where sd.trading_year=t1.max_year and
sd.trading_month=st1.max_month and sd.company_name=st1.company_name)stock_end,
(select company_name, state, sub_industry from stock_data
group by company_name,state,sub_industry)sd where (stock_end.close-stock_start.open)>0 and
stock_start.company_name=stock_end.company_name and sd.company_name=stock_start.company_name;
