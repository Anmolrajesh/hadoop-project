use anmolrajeshkumatigeranaly;

select * from Stockprices limit 5;