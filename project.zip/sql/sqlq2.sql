use anmolrajeshkumatigeranaly;

select * from Stockcompanies limit 5;